package com.modele.contact.contacts;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateDeleteActivity extends AppCompatActivity {

    private UserModel userModel;
    private EditText etname, ethobby;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);
        setTitle("Manage Contact");
        Intent intent = getIntent();
        userModel = (UserModel) intent.getSerializableExtra("user");

        databaseHelper = new DatabaseHelper(this);

        etname = (EditText) findViewById(R.id.etname);
        ethobby = (EditText) findViewById(R.id.etphone);


        etname.setText(userModel.getName());
        ethobby.setText(userModel.getHobby());

    }

    public void save_mod(){
        if(etname.length()>0 || ethobby.length()>0) {
            databaseHelper.updateUser(userModel.getId(), etname.getText().toString(), ethobby.getText().toString());
            Toast.makeText(UpdateDeleteActivity.this, "Contact Modifier!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(UpdateDeleteActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }else {Toast.makeText(UpdateDeleteActivity.this, " champs vide", Toast.LENGTH_SHORT).show();}

    }
    public void delete(){
        databaseHelper.deleteUSer(userModel.getId());
        Toast.makeText(UpdateDeleteActivity.this, "Contact Supprimer!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(UpdateDeleteActivity.this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
    public void retoure(){
        Intent intentAdd = new Intent(UpdateDeleteActivity.this,MainActivity.class);
        startActivity(intentAdd);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        //ajoute les entrées de menu_test à l'ActionBar
        getMenuInflater().inflate(R.menu.menu_update, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_save_mod:
                save_mod();
                return true;
            case R.id.action_delete:
                delete();
                return true;
            case R.id.action_return:
                retoure();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
