package com.modele.contact.contacts;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
public class GetAllUsersActivity extends AppCompatActivity {


    private EditText etname, etphone;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Creer Contact");
        databaseHelper = new DatabaseHelper(this);

        etname = (EditText) findViewById(R.id.etname);
        etphone = (EditText) findViewById(R.id.etphone);

    }

    public void save (){
        if(etname.length()>0 || etphone.length()>0) {
            databaseHelper.addUserDetail(etname.getText().toString(), etphone.getText().toString());
            etname.setText("");
            etphone.setText("");
            Intent intent = new Intent(GetAllUsersActivity.this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(GetAllUsersActivity.this, "Contact Enregistrer", Toast.LENGTH_SHORT).show();
        }else {Toast.makeText(GetAllUsersActivity.this, "Les champs sont obligatoire", Toast.LENGTH_SHORT).show();}
    }

    public void retoure(){
        Intent intentAdd = new Intent(GetAllUsersActivity.this,MainActivity.class);
        startActivity(intentAdd);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        //ajoute les entrées de menu_test à l'ActionBar
        getMenuInflater().inflate(R.menu.menu_save, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_save:
                save();
                return true;
            case R.id.action_revert:
                retoure();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
